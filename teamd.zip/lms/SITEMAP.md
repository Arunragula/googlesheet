# LearnHub Site Map & Navigation Guide

## Complete User Journey

```
┌─────────────────────────────────────────────────────────────────┐
│                          Landing Page                            │
│                     (index.html)                                 │
│  ┌─────────────────────────────────────────────────────────┐   │
│  │ Navigation Bar                                          │   │
│  │ - LearnHub Logo      - Features Link    - Sign Up      │   │
│  │ - Courses Link       - Pricing Link     - Login        │   │
│  └─────────────────────────────────────────────────────────┘   │
│                                                                   │
│  ┌─────────────────────────────────────────────────────────┐   │
│  │ Hero Section                                            │   │
│  │ - Main Headline      - Call-to-action Button           │   │
│  │ - Subheading         - Secondary Button                │   │
│  └─────────────────────────────────────────────────────────┘   │
│                                                                   │
│  ┌─────────────────────────────────────────────────────────┐   │
│  │ Features Section (6 Cards)                              │   │
│  │ - Comprehensive Curriculum     - Expert Instructors    │   │
│  │ - Recognized Certificates      - Learn on the Go       │   │
│  │ - Track Progress               - 24/7 Support          │   │
│  └─────────────────────────────────────────────────────────┘   │
│                                                                   │
│  ┌─────────────────────────────────────────────────────────┐   │
│  │ Courses Section (6 Sample Courses)                      │   │
│  │ - Web Development Bootcamp     - Data Science Mastery  │   │
│  │ - UI/UX Design                 - React Native Dev      │   │
│  │ - AWS Cloud Computing          - Digital Marketing     │   │
│  └─────────────────────────────────────────────────────────┘   │
│                                                                   │
│  ┌─────────────────────────────────────────────────────────┐   │
│  │ Call-to-Action Section                                 │   │
│  │ - "Ready to Start Learning?"   - Sign Up Button        │   │
│  └─────────────────────────────────────────────────────────┘   │
│                                                                   │
│  ┌─────────────────────────────────────────────────────────┐   │
│  │ Footer                                                  │   │
│  │ - About - Quick Links - Company - Social Media        │   │
│  │ - Copyright & Links                                    │   │
│  └─────────────────────────────────────────────────────────┘   │
└─────────────────────────────────────────────────────────────────┘
         ↓ Sign Up / Login                        ↓ View Course
    
┌─────────────────────────────┐            ┌──────────────────────┐
│  Authentication Modals      │            │  Course Detail Page  │
│  ┌───────────────────────┐  │            │  (course-detail.html)│
│  │ Signup Modal          │  │            │ ┌──────────────────┐ │
│  │ - Username            │  │            │ │ Course Header    │ │
│  │ - Email               │  │            │ │ - Title          │ │
│  │ - Password            │  │            │ │ - Description    │ │
│  │ - Role Selection      │  │            │ │ - Instructor     │ │
│  │ - Sign Up Button      │  │            │ │ - Price          │ │
│  │ - Login Link          │  │            │ └──────────────────┘ │
│  └───────────────────────┘  │            │                      │
│  ┌───────────────────────┐  │            │ ┌──────────────────┐ │
│  │ Login Modal           │  │            │ │ Course Content   │ │
│  │ - Username            │  │            │ │ - Overview       │ │
│  │ - Password            │  │            │ │ - Curriculum     │ │
│  │ - Login Button        │  │            │ │ - Instructor Bio │ │
│  │ - Sign Up Link        │  │            │ └──────────────────┘ │
│  └───────────────────────┘  │            │                      │
│                              │            │ ┌──────────────────┐ │
│      Success → Redirect      │            │ │ Sidebar          │ │
│      to Dashboard            │            │ │ - Price          │ │
└─────────────────────────────┘            │ │ - Enroll Button  │ │
         ↓                                   │ │ - What's Include │ │
         │                                   │ │ - Reviews        │ │
         ├─ Student Role                    │ └──────────────────┘ │
         │                                   └──────────────────────┘
         │                                            ↓
         │                                   Enroll in Course
         ↓                                            ↓
┌──────────────────────────────────────────────────────┐
│        Student Dashboard                             │
│     (student_dashboard.html)                         │
│  ┌───────────────────────────────────────────────┐  │
│  │ Navigation Bar (with Logout)                  │  │
│  │ - LearnHub Logo                               │  │
│  │ - User Greeting                               │  │
│  │ - Logout Button                               │  │
│  └───────────────────────────────────────────────┘  │
│                                                      │
│  ┌──────────────┐  ┌─────────────────────────────┐ │
│  │ Sidebar      │  │ Main Content                │ │
│  │ ┌──────────┐ │  │ ┌─────────────────────────┐ │ │
│  │ │Dashboard │ │  │ │ Welcome Section         │ │ │
│  │ │My Courses│ │  │ │ ┌──────────────────────┐ │ │ │
│  │ │Progress  │ │  │ │ │ Stats Grid (4 cards) │ │ │ │
│  │ │Certs     │ │  │ │ │ - Courses Enrolled   │ │ │ │
│  │ │Profile   │ │  │ │ │ - Avg Progress       │ │ │ │
│  │ │Home Link │ │  │ │ │ - Certificates       │ │ │ │
│  │ └──────────┘ │  │ │ │ - Hours Learned      │ │ │ │
│  └──────────────┘  │ │ └──────────────────────┘ │ │ │
│                     │ │                         │ │ │
│                     │ │ Your Learning Journey   │ │ │
│                     │ │ ┌──────────────────────┐ │ │ │
│                     │ │ │ Continue Learning    │ │ │ │
│                     │ │ │ (Enrolled Courses)   │ │ │ │
│                     │ │ │ - Progress Bars      │ │ │ │
│                     │ │ │ - Course Cards       │ │ │ │
│                     │ │ └──────────────────────┘ │ │ │
│                     │ └─────────────────────────┘ │ │
│                     └─────────────────────────────┘ │
│                                                      │
│ Can View:                                           │
│ - My Courses (with progress bars)                  │
│ - Progress Analytics                               │
│ - Certificates (when earned)                       │
│ - Profile Information (editable)                   │
└──────────────────────────────────────────────────────┘
         ↓ If Instructor Role
         
┌──────────────────────────────────────────────────────┐
│        Instructor Dashboard                           │
│     (instructor_dashboard.html)                       │
│  ┌───────────────────────────────────────────────┐  │
│  │ Navigation Bar (with Logout)                  │  │
│  │ - LearnHub Logo                               │  │
│  │ - User Greeting                               │  │
│  │ - Create Course Button                        │  │
│  └───────────────────────────────────────────────┘  │
│                                                      │
│  ┌──────────────┐  ┌─────────────────────────────┐ │
│  │ Sidebar      │  │ Main Content                │ │
│  │ ┌──────────┐ │  │ ┌─────────────────────────┐ │ │
│  │ │Dashboard │ │  │ │ Instructor Dashboard    │ │ │
│  │ │My Courses│ │  │ │ ┌──────────────────────┐ │ │ │
│  │ │Analytics │ │  │ │ │ Stats Grid (4 cards) │ │ │ │
│  │ │Students  │ │  │ │ │ - Courses Created    │ │ │ │
│  │ │Profile   │ │  │ │ │ - Total Students     │ │ │ │
│  │ │Home Link │ │  │ │ │ - Enrollments        │ │ │ │
│  │ └──────────┘ │  │ │ │ - Active Courses     │ │ │ │
│  └──────────────┘  │ │ └──────────────────────┘ │ │ │
│                     │ │                         │ │ │
│                     │ │ Teaching Overview       │ │ │
│                     │ │ ┌──────────────────────┐ │ │ │
│                     │ │ │ Your Courses         │ │ │ │
│                     │ │ │ - Course Cards       │ │ │ │
│                     │ │ │ - Edit Buttons       │ │ │ │
│                     │ │ └──────────────────────┘ │ │ │
│                     │ │                         │ │ │
│                     │ │ Recent Enrollments      │ │ │
│                     │ │ ┌──────────────────────┐ │ │ │
│                     │ │ │ Enrollment Table     │ │ │ │
│                     │ │ │ - Student Name       │ │ │ │
│                     │ │ │ - Course             │ │ │ │
│                     │ │ │ - Enrollment Date    │ │ │ │
│                     │ │ └──────────────────────┘ │ │ │
│                     │ └─────────────────────────┘ │ │
│                     └─────────────────────────────┘ │
│                                                      │
│ Can View/Do:                                        │
│ - Create Courses (Modal Form)                      │
│ - Manage Courses (Edit/Delete)                     │
│ - View Course Analytics                            │
│ - View Student Roster                              │
│ - Track Enrollments                                │
│ - Update Profile                                   │
└──────────────────────────────────────────────────────┘
```

## Navigation Paths

### From Landing Page
```
Landing Page
├─ Sign Up → Signup Modal → Create Account → Dashboard
├─ Login → Login Modal → Enter Credentials → Dashboard
├─ Explore Courses → Browse Courses
├─ Course Card → Course Detail Page
└─ Features/Pricing → Scroll to section
```

### From Student Dashboard
```
Student Dashboard
├─ Dashboard (Home) → Stats & Overview
├─ My Courses → Enrolled Courses List
├─ Progress → Learning Analytics
├─ Certificates → Earned Certificates
├─ Profile → Edit Profile Info
├─ Home Link → Back to Landing
└─ Logout → Redirect to Landing
```

### From Instructor Dashboard
```
Instructor Dashboard
├─ Dashboard (Home) → Stats & Overview
├─ My Courses → Manage Courses
├─ Analytics → Course Performance
├─ Students → Student Roster
├─ Profile → Edit Profile
├─ Create Course Button → Open Modal
├─ Home Link → Back to Landing
└─ Logout → Redirect to Landing
```

### From Course Detail Page
```
Course Detail Page
├─ Enroll Now → Post to API → Redirect to Dashboard
├─ Login (if not logged in) → Open Login Modal
├─ Back to Home → Return to Landing
└─ Course Actions
    ├─ View Curriculum
    ├─ Read Overview
    ├─ Review Pricing
    └─ Check Instructor Bio
```

## Page Structure Overview

### Landing Page (index.html)
```
Header (Navigation)
├─ Logo/Brand
├─ Nav Links
├─ Login Button
└─ Sign Up Button

Hero Section
├─ Main Headline
├─ Subheading
└─ CTA Buttons

Features Section (Grid)
├─ Feature 1: Curriculum
├─ Feature 2: Instructors
├─ Feature 3: Certificates
├─ Feature 4: Mobile
├─ Feature 5: Progress
└─ Feature 6: Support

Courses Section (Grid)
├─ Course Cards (6 total)
│  ├─ Course Header (Icon)
│  ├─ Category Badge
│  ├─ Title
│  ├─ Instructor Name
│  ├─ Description
│  └─ Footer (Price + Enroll Button)

CTA Section
├─ Headline
├─ Subtext
└─ Sign Up Button

Footer
├─ Company Info
├─ Quick Links
├─ Support Links
└─ Social Media

Modals (Hidden)
├─ Login Modal
│  ├─ Username Field
│  ├─ Password Field
│  └─ Login Button
└─ Signup Modal
   ├─ Username Field
   ├─ Email Field
   ├─ Password Field
   ├─ Role Selection
   └─ Sign Up Button
```

### Dashboard (student_dashboard.html)
```
Navigation Bar
├─ Logo/Brand
├─ User Greeting
└─ Logout Button

Main Dashboard (Grid Layout)
├─ Sidebar (250px)
│  └─ Menu Links
│     ├─ Dashboard
│     ├─ My Courses
│     ├─ Progress
│     ├─ Certificates
│     ├─ Profile
│     └─ Home

Main Content
├─ Content Header
│  ├─ Title
│  └─ Action Buttons

Stats Grid (4 Cards)
├─ Courses Enrolled
├─ Average Progress
├─ Certificates
└─ Hours Learned

Content Sections
├─ Dashboard Section (Default)
│  ├─ Your Learning Journey
│  ├─ Continue Learning (Courses Grid)
│  └─ Recent Activity
├─ My Courses Section (Hidden)
│  └─ Enrolled Courses (Grid)
├─ Progress Section (Hidden)
│  └─ Progress Analytics
├─ Certificates Section (Hidden)
│  └─ Earned Certificates
└─ Profile Section (Hidden)
   └─ Profile Form (Editable)
```

### Course Detail Page (course-detail.html)
```
Navigation Bar
├─ Logo/Brand
├─ Back Link
└─ Logout Button

Course Header (Hero)
├─ Breadcrumb Navigation
├─ Course Title
├─ Description
├─ Course Meta
│  ├─ Instructor Name
│  ├─ Level
│  ├─ Duration
│  └─ Price
└─ Enroll Button

Content Area (2-Column Grid)
├─ Left Column (2/3 width)
│  ├─ Course Overview Card
│  │  ├─ What you'll learn
│  │  ├─ Prerequisites
│  │  └─ Course includes
│  ├─ Curriculum Card
│  │  └─ Lesson List (numbered)
│  └─ Instructor Info Card
│     ├─ Instructor Avatar
│     ├─ Name
│     └─ Bio

└─ Right Column (1/3 width - Sticky)
   └─ Course Card
      ├─ Course Image
      ├─ Price Display
      ├─ Enroll Button
      ├─ Guarantee Notice
      └─ Features List

Footer
├─ About
├─ Links
└─ Copyright
```

## User Flow Diagram

```
Unauthenticated User
        ↓
Visit Landing Page
        ↓
    [Choose Path]
    ↙        ↘
Browse         Sign Up / Login
Courses             ↓
  ↓          [Create Account]
View Course         ↓
Detail          Authenticated
  ↓                 ↓
[Not Logged In]  [Choose Role]
     ↓           ↙    ↘
Sign Up       Student  Instructor
  ↓             ↓         ↓
Login    [Student Dashboard] [Instructor Dashboard]
  ↓             ↓              ↓
[Student]    Browse      Create Courses
Dashboard    Courses      Manage Courses
  ↓             ↓              ↓
Browse        Enroll       View Students
Courses         ↓              ↓
  ↓         [Student Dashboard] Track Progress
View Course     ↓              ↓
Details      Track Progress   Analytics
  ↓             ↓              ↓
Enroll        View Certs    Manage Courses
Course          ↓
  ↓          [Completed]
[In Course]
  ↓
Complete Course
  ↓
Earn Certificate
  ↓
[Completed]
```

## Responsive Breakpoints

```
Mobile (320px - 767px)
├─ Single Column Layout
├─ Stacked Navigation
├─ Full-width Components
└─ Touch-friendly Buttons

Tablet (768px - 1024px)
├─ Two Column Grid
├─ Sidebar Navigation
├─ Optimized Spacing
└─ Balanced Layout

Desktop (1025px - 1920px)
├─ Full Grid Layouts
├─ Side-by-side Content
├─ Hover Effects
└─ Maximum Width: 1200px

Ultra-wide (2560px+)
├─ Larger Spacing
├─ Bigger Text
├─ Enhanced Visuals
└─ Maximum Width: 1400px
```

---

## Complete Navigation Map

### Pages Accessible
1. **Landing Page** (`/`) - No login required
2. **Course Detail** (`/course-detail.html?id=X`) - Optional login
3. **Student Dashboard** (`/student-dashboard.html`) - Student login required
4. **Instructor Dashboard** (`/instructor-dashboard.html`) - Instructor login required

### Features by Role

**Guest (Not Logged In)**
- View landing page
- Browse course list
- View course details
- Sign up / Login

**Student**
- All guest features
- Personal dashboard
- Enroll in courses
- View progress
- Edit profile
- View certificates

**Instructor**
- All student features
- Create courses
- Manage courses
- View students
- Track analytics
- Edit courses

---

This completes the full site navigation and structure!
