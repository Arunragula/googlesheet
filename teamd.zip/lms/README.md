# LearnHub - Professional Online Learning Management System

A modern, full-featured Learning Management System built with Python, SQLite, HTML, CSS, Bootstrap, and JavaScript.

## Features

### User Roles
- **Students**: Enroll in courses, track progress, earn certificates
- **Instructors**: Create and manage courses, track student engagement
- **Admins**: System management and analytics

### Core Features
✅ User authentication and session management  
✅ Course creation and management  
✅ Student enrollment system  
✅ Progress tracking  
✅ Responsive design with modern UI  
✅ Real-time notifications  
✅ Role-based access control  

## Tech Stack

- **Frontend**: HTML5, CSS3, Bootstrap 5, JavaScript (Vanilla)
- **Backend**: Python 3.13
- **Database**: SQLite
- **Server**: Python HTTP Server with socketserver

## Installation & Setup

### Prerequisites
- Python 3.13+
- Modern web browser
- Internet connection

### Step 1: Initialize Database

```powershell
cd c:\Users\aruna\OneDrive\Desktop\lms\lms_project
python database.py
```

### Step 2: Start the Server

```powershell
python server.py
```

You should see:
```
🚀 LMS Server running at http://localhost:8000
📚 Access the platform in your browser
```

### Step 3: Open in Browser

Navigate to: `http://localhost:8000`

## Project Structure

```
lms/
├── lms_project/
│   ├── server.py              # Main backend server
│   ├── database.py            # Database initialization and connection
│   ├── session_manager.py     # User session management
│   └── lms.db                 # SQLite database (auto-created)
└── templates/
    ├── index.html             # Landing page
    ├── main.css               # Global styles
    ├── main.js                # Global JavaScript
    ├── student_dashboard.html  # Student interface
    ├── dashboard.js           # Student dashboard logic
    ├── instructor_dashboard.html # Instructor interface
    └── instructor_dashboard.js   # Instructor dashboard logic
```

## API Endpoints

### Authentication
- `POST /api/register` - Register new user
- `POST /api/login` - User login

### Courses
- `GET /api/courses` - Get all courses
- `GET /api/my-courses` - Get enrolled courses
- `POST /api/create-course` - Create new course
- `POST /api/enroll-course` - Enroll in course

### User
- `GET /api/user` - Get current user info
- `POST /api/update-profile` - Update profile

## Database Schema

### Users Table
```sql
CREATE TABLE users (
    id INTEGER PRIMARY KEY,
    username TEXT UNIQUE NOT NULL,
    password TEXT NOT NULL,
    email TEXT UNIQUE NOT NULL,
    role TEXT (admin|instructor|student),
    bio TEXT,
    profile_picture TEXT,
    created_at TIMESTAMP,
    updated_at TIMESTAMP
)
```

### Courses Table
```sql
CREATE TABLE courses (
    id INTEGER PRIMARY KEY,
    title TEXT NOT NULL,
    description TEXT,
    category TEXT,
    instructor_id INTEGER,
    thumbnail TEXT,
    price REAL,
    level TEXT,
    duration_hours REAL,
    created_at TIMESTAMP
)
```

### Additional Tables
- **lessons** - Course lessons/modules
- **enrollments** - Student course enrollments
- **assessments** - Quizzes and assignments
- **submissions** - Student assessment submissions

## Usage Guide

### For Students
1. Visit the landing page and click "Sign Up"
2. Create account with student role
3. Browse and enroll in courses
4. Access dashboard to track progress
5. View certificates upon completion

### For Instructors
1. Sign up with instructor role
2. Create courses in the instructor dashboard
3. Add course content and lessons
4. Monitor student progress and engagement
5. Provide feedback and grades

### For Admins
1. Access admin dashboard (auto-assigned on registration with admin role)
2. Manage users and courses
3. View system analytics
4. Configure platform settings

## Customization

### Change Server Port
Edit `server.py`:
```python
PORT = 8000  # Change this value
```

### Update Colors
Edit `templates/main.css`:
```css
:root {
    --primary: #6366f1;
    --secondary: #ec4899;
    /* Update other colors */
}
```

### Add New Features
1. Add database tables in `database.py`
2. Create API endpoints in `server.py`
3. Build UI in HTML templates
4. Add JavaScript functionality

## Troubleshooting

### Database not found
```powershell
# Reinitialize database
python lms_project/database.py
```

### Port already in use
```powershell
# Change PORT in server.py to different value (e.g., 8001)
```

### CSS/JS not loading
```
# Clear browser cache (Ctrl+Shift+Delete)
# Hard refresh (Ctrl+Shift+R)
```

### Session expired
- Login again to create new session
- Sessions expire after 24 hours of inactivity

## Security Notes

⚠️ **Important**: This is a learning/demo project. For production:
- Hash passwords using bcrypt or similar
- Use HTTPS instead of HTTP
- Implement CSRF protection
- Add input validation and sanitization
- Use a production web server (Gunicorn, uWSGI)
- Add rate limiting
- Implement proper error handling
- Add security headers

## Performance Tips

- Database: Use indexes for frequent queries
- Backend: Implement caching for course listings
- Frontend: Lazy load images and heavy content
- Sessions: Implement automatic cleanup of expired sessions

## Future Enhancements

- [ ] Video upload and streaming
- [ ] Real-time chat/messaging
- [ ] Mobile app (React Native)
- [ ] Payment gateway integration
- [ ] AI-powered recommendations
- [ ] Advanced analytics dashboard
- [ ] Certificate generation (PDF)
- [ ] Discussion forums
- [ ] Live classes/webinars
- [ ] Multi-language support

## Support

For issues or questions:
1. Check the troubleshooting section
2. Review error messages in browser console
3. Check server logs in terminal

## License

This project is open source and available for educational purposes.

## Author

Team 1 - Academic Major Project
Online Learning Management System (LMS)

---

**Happy Learning! 🚀**
