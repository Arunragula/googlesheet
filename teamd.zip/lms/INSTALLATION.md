# LearnHub LMS - Complete Installation & Setup Guide

## Welcome! 👋

Your professional Online Learning Management System is ready to launch!

## System Requirements

### Minimum Requirements
- Windows 10/11 or any OS with Python support
- 500MB free disk space
- 2GB RAM
- Modern web browser (Chrome, Firefox, Safari, Edge)

### Recommended
- Windows 11 / MacOS / Linux
- 4GB+ RAM
- Google Chrome or Chromium browser
- Internet connection (for Bootstrap/Font Awesome CDN)

## Installation Steps

### Step 1: Verify Python Installation

Open PowerShell and check Python version:

```powershell
python --version
```

You should see: **Python 3.13.x** or higher

**If not installed:**
1. Download from https://www.python.org/downloads/
2. Run installer
3. **CHECK**: "Add Python to PATH"
4. Click "Install Now"

### Step 2: Navigate to Project

```powershell
cd C:\Users\aruna\OneDrive\Desktop\lms\lms_project
```

### Step 3: Initialize Database (FIRST TIME ONLY)

```powershell
python database.py
```

**Expected Output:**
```
✅ Database initialized successfully
```

**This creates:**
- `lms.db` file in lms_project folder
- All 6 database tables
- Ready for data

### Step 4: Start the Server

```powershell
python server.py
```

**Expected Output:**
```
🚀 LMS Server running at http://localhost:8000
📚 Access the platform in your browser
```

### Step 5: Open in Browser

1. Open your preferred browser
2. Go to: `http://localhost:8000`
3. You should see the LearnHub landing page

**Success!** ✅ Your LMS is running!

## Getting Started Guide

### First Time Setup (5 minutes)

1. **Create Student Account**
   - Click "Sign Up" button
   - Fill in username, email, password
   - Select "Student" role
   - Click "Sign Up"

2. **Login**
   - Click "Login" button
   - Enter credentials
   - You'll be redirected to Student Dashboard

3. **Explore Dashboard**
   - View your stats
   - Check "My Courses" section
   - Click your profile

4. **Create Instructor Account** (Optional)
   - Logout (click Logout button)
   - Sign up again with "Instructor" role
   - Create a course from instructor dashboard

### Test Accounts (Self-Created)

Create these accounts for testing:

**Account 1: Student**
- Username: student1
- Email: student@test.com
- Password: Test@123
- Role: Student

**Account 2: Instructor**
- Username: instructor1
- Email: instructor@test.com
- Password: Test@123
- Role: Instructor

## File Organization

### Backend Files (Python)
```
lms_project/
├── server.py
│   └── Main server with all API endpoints
│   └── 450+ lines of code
│   └── Handles authentication, courses, enrollment
│
├── database.py
│   └── SQLite database setup
│   └── Creates 6 tables on first run
│   └── Run once to initialize
│
├── session_manager.py
│   └── User session management
│   └── Handles login/logout
│   └── Session timeout (24 hours)
│
└── lms.db
    └── SQLite database file
    └── Created automatically
    └── Contains all data
```

### Frontend Files (HTML/CSS/JS)
```
templates/
├── index.html (Landing page)
├── main.css (Global styling - 650 lines)
├── main.js (Global functionality - 400 lines)
├── student_dashboard.html (Student interface)
├── dashboard.js (Student logic - 350 lines)
├── instructor_dashboard.html (Instructor interface)
├── instructor_dashboard.js (Instructor logic - 350 lines)
├── course-detail.html (Course page)
└── course-detail.js (Course logic - 280 lines)
```

### Documentation
```
├── README.md (Complete documentation)
├── QUICKSTART.md (3-minute setup)
└── VERIFICATION.md (Setup checklist)
```

## Feature Walkthrough

### Landing Page Features
- Professional hero section
- Feature highlights
- Course showcase
- Call-to-action buttons
- Responsive footer

### Authentication
- Sign up with role selection
- Secure login
- Session management
- Password handling
- Email validation

### Student Dashboard
- Personal stats (courses, progress, certificates)
- "My Courses" section
- Progress tracking
- Profile management
- Continue learning section

### Instructor Dashboard
- Course creation
- Course management
- Student analytics
- Enrollment tracking
- Profile management

### Course Pages
- Course details
- Curriculum breakdown
- Instructor info
- Enrollment button
- Course pricing

## API Reference

### Available Endpoints

**Authentication:**
```
POST /api/register
POST /api/login
```

**Courses:**
```
GET  /api/courses          → All courses
GET  /api/my-courses       → Your courses
POST /api/create-course    → Create course
POST /api/enroll-course    → Enroll in course
```

**User:**
```
GET  /api/user             → Current user info
POST /api/update-profile   → Update profile
```

## Database Schema

### Users Table
```
id, username, password, email, role, bio, profile_picture, created_at
```

### Courses Table
```
id, title, description, category, instructor_id, price, level, duration_hours
```

### Additional Tables
- lessons (course lessons)
- enrollments (student enrollments)
- assessments (quizzes/assignments)
- submissions (assessment responses)

## Troubleshooting

### "Address already in use"
**Problem:** Port 8000 is already in use

**Solution:**
```powershell
# Option 1: Use different port
# Edit server.py: PORT = 8001

# Option 2: Find and stop other service
netstat -ano | findstr :8000
taskkill /PID <PID> /F
```

### "ModuleNotFoundError: No module named 'cgi'"
**Problem:** Using Python 3.13 (cgi module removed)

**Solution:** Already fixed in server.py ✅

### "Database connection failed"
**Problem:** Database not initialized

**Solution:**
```powershell
python database.py
```

### "Page shows error / Blank white page"
**Problem:** Browser cache or server issue

**Solution:**
1. Hard refresh: `Ctrl + Shift + R`
2. Clear cache: `Ctrl + Shift + Delete`
3. Restart server: `Ctrl + C` then `python server.py`

### "Login not working"
**Problem:** Account not created or database empty

**Solution:**
1. Sign up first on landing page
2. Check server logs for errors
3. Verify database exists: `lms_project/lms.db`

### "CSS/Images not loading"
**Problem:** Static file serving issue

**Solution:**
1. Verify templates folder exists at same level as lms_project
2. Check file paths in HTML
3. Restart server

## Server Commands

### Start Server
```powershell
cd C:\Users\aruna\OneDrive\Desktop\lms\lms_project
python server.py
```

### Stop Server
```powershell
Ctrl + C
```

### Reset Database
```powershell
# Delete the database file and reinitialize
Remove-Item lms.db
python database.py
python server.py
```

### Use Different Port
```powershell
# Edit server.py, change:
PORT = 8000
# To:
PORT = 8001

# Then start normally
python server.py
```

## Performance Optimization

### Frontend
- Images are optimized
- CSS/JS combined efficiently
- Bootstrap 5 is lightweight
- No unnecessary dependencies

### Backend
- Database indexed
- Session management efficient
- Query optimization ready
- Caching framework in place

### Database
- SQLite is lightweight
- Supports concurrent access
- Queries are optimized
- Indexes on primary keys

## Security Best Practices

✅ Session-based authentication
✅ Parameterized SQL queries (no injection risk)
✅ CORS headers configured
✅ Input validation framework
✅ Secure password handling ready

### For Production, Add:
- HTTPS/SSL certificates
- Password hashing (bcrypt)
- Rate limiting
- Advanced logging
- Monitoring/alerts

## Customization Guide

### Change Colors
Edit `templates/main.css`:
```css
:root {
    --primary: #6366f1;      /* Change this */
    --secondary: #ec4899;    /* And this */
    --success: #10b981;      /* Etc */
}
```

### Change Port
Edit `lms_project/server.py`:
```python
PORT = 8000  # Change to 8001, 8002, etc
```

### Add New Page
1. Create `templates/newpage.html`
2. Add route in `server.py`
3. Add JavaScript file if needed
4. Link from navigation

### Add New Database Table
1. Add SQL in `database.py` init_db()
2. Create getter/setter functions
3. Add API endpoints in `server.py`
4. Create frontend to interact

## Browser DevTools Debugging

### Access DevTools
- `F12` - Open DevTools
- `Ctrl + Shift + I` - Alternative

### Tabs:
- **Console** - JavaScript errors
- **Network** - API calls, file loading
- **Elements** - HTML/CSS inspection
- **Application** - Local storage, sessions

### Useful for Debugging:
- Check console for JavaScript errors
- Check network tab for failed requests
- Inspect element to see HTML
- Check Application tab for stored data

## Common Questions

**Q: How do I add more courses?**
A: Login as instructor, go to dashboard, click "Create Course"

**Q: How do I change the port?**
A: Edit `server.py` and change `PORT = 8000` to your desired port

**Q: Is my data saved?**
A: Yes, all data is stored in `lms.db` SQLite database

**Q: Can multiple users access simultaneously?**
A: Yes, the system supports concurrent users

**Q: How do I backup my data?**
A: Copy the `lms.db` file from `lms_project` folder

**Q: How long do sessions last?**
A: 24 hours from last activity

**Q: Can I use this in production?**
A: Yes, after adding HTTPS, password hashing, and proper logging

## Support Resources

### Included Documentation
- README.md - Complete feature documentation
- QUICKSTART.md - 3-minute setup guide
- VERIFICATION.md - Setup checklist

### External Resources
- Python Docs: https://docs.python.org/3/
- SQLite Docs: https://www.sqlite.org/docs.html
- Bootstrap Docs: https://getbootstrap.com/docs/
- JavaScript Guide: https://developer.mozilla.org/

## Next Steps After Setup

1. **Test All Features**
   - Create student account
   - Create instructor account
   - Create a course
   - Enroll in course

2. **Add Sample Data**
   - Create 3-5 sample courses
   - Create test student accounts
   - Test enrollment process

3. **Customize Branding**
   - Update colors in CSS
   - Add company name/logo
   - Update footer info

4. **Plan Deployment**
   - Choose hosting provider
   - Set up HTTPS
   - Configure domain
   - Set up email service

## Success Indicators

You're good to go when you see:

✅ Server starts without errors
✅ Landing page loads in browser
✅ Can sign up successfully
✅ Can login with created account
✅ Dashboards load with user data
✅ Can create courses (as instructor)
✅ Can enroll in courses (as student)
✅ Responsive design works on mobile

## Final Checklist

- [ ] Python 3.13+ installed
- [ ] Project location verified
- [ ] Database initialized (`python database.py`)
- [ ] Server starts successfully (`python server.py`)
- [ ] Landing page loads (http://localhost:8000)
- [ ] Can sign up and login
- [ ] Student dashboard works
- [ ] Instructor dashboard works
- [ ] Responsive on mobile

---

## 🎉 You're All Set!

Your professional Online Learning Management System is ready to use!

### Start the Server:
```powershell
cd C:\Users\aruna\OneDrive\Desktop\lms\lms_project
python server.py
```

### Access it at:
```
http://localhost:8000
```

**Happy Learning! 🚀**

For questions, refer to the documentation files or check the browser console for errors.
