// ================================
// Course Detail Page
// ================================
let courseId = null;
let courseData = null;

document.addEventListener('DOMContentLoaded', () => {
    getQueryParam();
    loadCourseDetails();
    checkUserStatus();
});

// ================================
// Get Course ID from URL
// ================================
function getQueryParam() {
    const urlParams = new URLSearchParams(window.location.search);
    courseId = urlParams.get('id');

    if (!courseId) {
        window.location.href = '/';
    }
}

// ================================
// Load Course Details
// ================================
async function loadCourseDetails() {
    try {
        const response = await fetch(`/api/course-detail?id=${encodeURIComponent(courseId)}`, { credentials: 'same-origin' });
        const data = await response.json();

        if (data.status === 'success') {
            courseData = data.course;
            courseData.lessons = data.lessons || [];
            displayCourseDetails(courseData);
            return;
        }
        throw new Error('Course not found');
    } catch (error) {
        console.error('Error loading course detail:', error);
        // Fallback to previous behaviour
        try {
            const response = await fetch('/api/courses');
            const data = await response.json();
            if (data.status === 'success') {
                let course = data.courses.find(c => c.id === parseInt(courseId));
                if (!course) course = getSampleCourse(parseInt(courseId));
                courseData = course;
                displayCourseDetails(course);
                return;
            }
        } catch (e) {}
        courseData = getSampleCourse(parseInt(courseId));
        displayCourseDetails(courseData);
    }
}

function getSampleCourse(id) {
    const courses = [
        {
            id: 1,
            title: "Complete Web Development Bootcamp",
            description: "Master HTML, CSS, JavaScript, and modern frameworks like React. Build real-world projects and launch your web development career.",
            category: "Web Development",
            instructor_name: "John Smith",
            price: 99.99,
            level: "Beginner",
            duration_hours: 40,
            lessons_count: 14,
            students_count: 5240,
            thumbnail_url: "https://images.unsplash.com/photo-1498050108023-c5249f4df085?auto=format&fit=crop&w=900&q=80"
        },
        {
            id: 2,
            title: "Python for Data Science",
            description: "Learn data analysis, visualization, and machine learning with Python. Perfect for aspiring data scientists.",
            category: "Data Science",
            instructor_name: "Sarah Johnson",
            price: 89.99,
            level: "Intermediate",
            duration_hours: 35,
            lessons_count: 12,
            students_count: 3120,
            thumbnail_url: "https://images.unsplash.com/photo-1519389950473-47ba0277781c?auto=format&fit=crop&w=900&q=80"
        },
        {
            id: 3,
            title: "UI/UX Design Fundamentals",
            description: "Create stunning user experiences with modern design principles. Learn tools like Figma and Adobe XD.",
            category: "Design",
            instructor_name: "Emma Davis",
            price: 79.99,
            level: "Beginner",
            duration_hours: 30,
            lessons_count: 10,
            students_count: 2890,
            thumbnail_url: "https://images.unsplash.com/photo-1500530855697-b586d89ba3ee?auto=format&fit=crop&w=900&q=80"
        },
        {
            id: 4,
            title: "Mobile App Development with React Native",
            description: "Build cross-platform mobile apps for iOS and Android using React Native and modern JavaScript.",
            category: "Mobile Development",
            instructor_name: "Michael Chen",
            price: 109.99,
            level: "Advanced",
            duration_hours: 45,
            lessons_count: 16,
            students_count: 1950,
            thumbnail_url: "https://images.unsplash.com/photo-1522202176988-66273c2fd55f?auto=format&fit=crop&w=900&q=80"
        },
        {
            id: 5,
            title: "Cloud Computing with AWS",
            description: "Deploy and scale applications on Amazon Web Services. Learn EC2, S3, Lambda, and more.",
            category: "Cloud",
            instructor_name: "Alex Rodriguez",
            price: 119.99,
            level: "Intermediate",
            duration_hours: 50,
            lessons_count: 18,
            students_count: 1640,
            thumbnail_url: "https://images.unsplash.com/photo-1487058792275-0ad4aaf24ca7?auto=format&fit=crop&w=900&q=80"
        },
        {
            id: 6,
            title: "Digital Marketing Mastery",
            description: "Learn SEO, SEM, content marketing, and social media strategies. Grow your online presence effectively.",
            category: "Marketing",
            instructor_name: "Lisa Wang",
            price: 69.99,
            level: "Beginner",
            duration_hours: 25,
            lessons_count: 8,
            students_count: 4320,
            thumbnail_url: "https://images.unsplash.com/photo-1460925895917-afdab827c52f?auto=format&fit=crop&w=900&q=80"
        }
    ];

    return courses.find(c => c.id === id) || courses[0];
}

// ================================
// Display Course Details
// ================================
function displayCourseDetails(course) {
    // Header section
    document.getElementById('courseTitle').textContent = course.title;
    document.getElementById('courseDescription').textContent = course.description;
    document.getElementById('breadcrumb').textContent = course.category;
    document.getElementById('instructorName').textContent = course.instructor_name;
    document.getElementById('courseLevel').textContent = course.level;
    document.getElementById('courseDuration').textContent = `${course.duration_hours || 40}h Course`;
    document.getElementById('coursePrice').textContent = formatCurrency(course.price || 0);
    document.getElementById('sidebarPrice').textContent = formatCurrency(course.price || 0);
    const inlinePrice = document.getElementById('coursePriceInline');
    if (inlinePrice) inlinePrice.textContent = formatCurrency(course.price || 0);
    document.getElementById('instructorNameDetail').textContent = course.instructor_name;
    const heroImage = document.getElementById('courseHeroImage');
    const sidebarImage = document.getElementById('courseSidebarImage');
    const thumb = getCourseThumbnail(course);
    if (heroImage) heroImage.src = thumb;
    if (sidebarImage) sidebarImage.src = thumb;

    updateEnrollButtons(course.is_enrolled === true);

    // Curriculum
    displayCurriculum(course);
}

function displayCurriculum(course) {
    const lessons = course.lessons || generateLessons(course);
    const isEnrolled = course.is_enrolled === true;
    
    const html = lessons.map((lesson, index) => {
        const watched = lesson.progress ? Math.round((lesson.progress.watched_seconds || 0)) : 0;
        const completed = lesson.progress ? lesson.progress.completed : false;
        const durationMinutes = lesson.duration_minutes || lesson.duration || 0;
        const durationText = durationMinutes ? `${durationMinutes} min` : '—';

        const rawVideoUrl = lesson.video_url || '';
        const normalizedVideoUrl = normalizeVideoUrl(rawVideoUrl);
        const safeVideoUrl = normalizedVideoUrl || rawVideoUrl;
        const hasVideo = safeVideoUrl && safeVideoUrl.trim() !== '';

        // Create lesson HTML with improved video access
        let lessonContent = `
            <div style="border: 1px solid var(--border); border-radius: 8px; overflow: hidden; margin-bottom: 12px;">
                <div style="padding: 16px; background: white; display: flex; justify-content: space-between; align-items: center; cursor: pointer;"
                     onclick="toggleLessonContent(${lesson.id || index})">
                    <div style="flex: 1;">
                        <div style="display: flex; align-items: center; gap: 10px; margin-bottom: 4px;">
                            <i class="fas fa-${completed ? 'check-circle' : 'play-circle'}" 
                               style="color: ${completed ? 'var(--success)' : 'var(--primary)'};"></i>
                            <strong>${escapeHtml(lesson.title)}</strong>
                        </div>
                        <div style="color: var(--gray); font-size: 14px; margin-left: 24px;">
                            ${durationText}
                            ${watched > 0 ? `<span style="margin-left: 12px;">• Watched ${watched}s</span>` : ''}
                            ${completed ? '<span style="margin-left: 12px; color: var(--success);">• Completed</span>' : ''}
                        </div>
                    </div>
                    <i class="fas fa-chevron-down" id="chevron-${lesson.id || index}" style="color: var(--gray); transition: transform 0.3s;"></i>
                </div>
                
                <div id="lesson-content-${lesson.id || index}" style="display: none; padding: 20px; background: #f8f9fa; border-top: 1px solid var(--border);">
        `;

        // Show video if enrolled and video exists
        if (isEnrolled && hasVideo) {
            const videoEmbedUrl = formatYouTubeEmbed(safeVideoUrl);
            lessonContent += `
                <div style="margin-bottom: 16px;">
                    <div style="position: relative; padding-bottom: 56.25%; height: 0; overflow: hidden; max-width: 100%; background: #000; border-radius: 8px;">
                        <iframe 
                            style="position: absolute; top: 0; left: 0; width: 100%; height: 100%;"
                            src="${videoEmbedUrl}" 
                            frameborder="0" 
                            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" 
                            allowfullscreen>
                        </iframe>
                    </div>
                    <div style="margin-top: 12px; display: flex; gap: 8px; flex-wrap: wrap;">
                        <a href="${safeVideoUrl}" target="_blank" rel="noopener" class="nav-button">
                            <i class="fas fa-external-link-alt"></i> Open in YouTube
                        </a>
                        ${!completed ? `
                            <button class="nav-button" onclick="event.stopPropagation(); markLessonWatched(${lesson.id || index}, ${durationMinutes * 60})">
                                <i class="fas fa-check"></i> Mark as Complete
                            </button>
                        ` : `
                            <span style="color: var(--success); padding: 8px 12px; display: inline-flex; align-items: center; gap: 6px;">
                                <i class="fas fa-check-circle"></i> Completed
                            </span>
                        `}
                    </div>
                </div>
            `;
        } else if (!isEnrolled && hasVideo) {
            // Not enrolled - show locked state
            lessonContent += `
                <div style="text-align: center; padding: 40px 20px; background: #fff; border-radius: 8px; border: 2px dashed var(--border);">
                    <i class="fas fa-lock" style="font-size: 48px; color: var(--gray); margin-bottom: 16px; opacity: 0.5;"></i>
                    <h4 style="margin-bottom: 8px;">Enroll to Access Video</h4>
                    <p style="color: var(--gray); margin-bottom: 20px;">This lesson includes video content available to enrolled students.</p>
                    <button class="cta-button" onclick="event.stopPropagation(); enrollNow()">
                        Enroll Now to Watch
                    </button>
                </div>
            `;
        } else if (isEnrolled && !hasVideo) {
            // Enrolled but no video
            lessonContent += `
                <div style="text-align: center; padding: 30px 20px; background: #fff; border-radius: 8px;">
                    <i class="fas fa-video-slash" style="font-size: 36px; color: var(--gray); margin-bottom: 12px; opacity: 0.5;"></i>
                    <p style="color: var(--gray);">The instructor hasn't uploaded a video for this lesson yet.</p>
                    <p style="color: var(--gray); font-size: 14px; margin-top: 8px;">Check back soon!</p>
                </div>
            `;
        } else {
            // Not enrolled and no video
            lessonContent += `
                <div style="padding: 20px; text-align: center;">
                    <p style="color: var(--gray);">${lesson.description || 'Lesson content will be available after enrollment.'}</p>
                </div>
            `;
        }

        lessonContent += `
                </div>
            </div>
        `;

        return lessonContent;
    }).join('');

    document.getElementById('curriculumContent').innerHTML = html || `
        <div style="text-align: center; padding: 40px; color: var(--gray);">
            <p><i class="fas fa-inbox"></i> No lessons available yet.</p>
        </div>
    `;
}

// Toggle lesson content visibility
function toggleLessonContent(lessonId) {
    const content = document.getElementById(`lesson-content-${lessonId}`);
    const chevron = document.getElementById(`chevron-${lessonId}`);
    
    if (content.style.display === 'none' || content.style.display === '') {
        content.style.display = 'block';
        if (chevron) chevron.style.transform = 'rotate(180deg)';
    } else {
        content.style.display = 'none';
        if (chevron) chevron.style.transform = 'rotate(0deg)';
    }
}

function normalizeVideoUrl(url) {
    if (!url) return '';
    url = url.trim();
    
    // Already an embed URL
    if (url.includes('youtube.com/embed/')) return url;
    if (url.includes('youtube-nocookie.com/embed/')) return url;
    
    // Extract video ID from various YouTube URL formats
    let videoId = null;
    
    // youtu.be/VIDEO_ID
    const youtubeShortMatch = url.match(/youtu\.be\/([a-zA-Z0-9_-]{11})/);
    if (youtubeShortMatch) {
        videoId = youtubeShortMatch[1];
    }
    
    // youtube.com/watch?v=VIDEO_ID
    const youtubeWatchMatch = url.match(/youtube\.com\/watch\?v=([a-zA-Z0-9_-]{11})/);
    if (youtubeWatchMatch) {
        videoId = youtubeWatchMatch[1];
    }
    
    // youtube.com/v/VIDEO_ID
    const youtubeVMatch = url.match(/youtube\.com\/v\/([a-zA-Z0-9_-]{11})/);
    if (youtubeVMatch) {
        videoId = youtubeVMatch[1];
    }
    
    if (videoId) {
        return `https://www.youtube.com/embed/${videoId}`;
    }
    
    return url;
}

function formatYouTubeEmbed(url) {
    const normalized = normalizeVideoUrl(url);
    if (normalized.includes('youtube.com/embed/')) {
        return normalized;
    }
    return url;
}

function escapeHtml(s){
    if(!s) return '';
    return s.replaceAll('&','&amp;').replaceAll('<','&lt;').replaceAll('>','&gt;');
}

function openInNewTab(url){ if(url && url !== '#') window.open(url, '_blank'); }

async function markLessonWatched(lessonId, seconds){
    if (!currentUser){ showAlert('Please login to track progress','info'); openModal('loginModal'); return; }
    try{
        const resp = await fetch('/api/lesson-progress', {
            method: 'POST',
            credentials: 'same-origin',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ lesson_id: lessonId, watched_seconds: seconds || 0, completed: true })
        });
        const data = await resp.json();
        if (data.status === 'success'){
            showAlert('Lesson marked as complete!','success');
            // reload course details to update UI
            loadCourseDetails();
        } else {
            showAlert(data.message || 'Failed to update progress','error');
        }
    }catch(e){ console.error('Mark watched error', e); showAlert('Connection error','error'); }
}

function generateLessons(course) {
    const lessonTitles = [
        "Getting Started & Course Overview",
        "Fundamentals & Core Concepts",
        "Advanced Techniques",
        "Practical Application",
        "Building Your First Project",
        "Project Development Part 1",
        "Project Development Part 2",
        "Best Practices & Optimization",
        "Real-world Case Study",
        "Troubleshooting & Common Issues",
        "Advanced Topics",
        "Final Project Walkthrough",
        "Career Path & Next Steps",
        "Q&A & Community Discussion"
    ];

    return lessonTitles.slice(0, course.lessons_count || 14).map((title, idx) => ({
        id: idx + 1,
        title,
        duration: Math.floor(Math.random() * 45) + 15 // 15-60 minutes
    }));
}

function formatCurrency(value) {
    const numberValue = Number(value || 0);
    return `₹${numberValue.toLocaleString('en-IN')}`;
}

function updateEnrollButtons(isEnrolled) {
    const headerBtn = document.getElementById('enrollNowBtn');
    const sidebarBtn = document.getElementById('enrollSidebarBtn');
    const inlineBtn = document.getElementById('enrollInlineBtn');
    const buttons = [headerBtn, sidebarBtn, inlineBtn].filter(Boolean);

    buttons.forEach(btn => {
        if (isEnrolled) {
            btn.textContent = '✓ Enrolled';
            btn.classList.add('enrolled');
            btn.disabled = true;
            btn.style.cursor = 'not-allowed';
        } else {
            btn.textContent = 'Enroll Now';
            btn.classList.remove('enrolled');
            btn.disabled = false;
            btn.style.cursor = 'pointer';
        }
    });
}

function getCourseThumbnail(course) {
    if (course.thumbnail_url) return course.thumbnail_url;
    if (course.thumbnail) return course.thumbnail;
    if (course.image_url) return course.image_url;

    const fallbackByCategory = {
        "Web Development": "https://images.unsplash.com/photo-1498050108023-c5249f4df085?auto=format&fit=crop&w=900&q=80",
        "Data Science": "https://images.unsplash.com/photo-1519389950473-47ba0277781c?auto=format&fit=crop&w=900&q=80",
        "Design": "https://images.unsplash.com/photo-1500530855697-b586d89ba3ee?auto=format&fit=crop&w=900&q=80",
        "Mobile Development": "https://images.unsplash.com/photo-1522202176988-66273c2fd55f?auto=format&fit=crop&w=900&q=80",
        "Cloud": "https://images.unsplash.com/photo-1487058792275-0ad4aaf24ca7?auto=format&fit=crop&w=900&q=80",
        "Marketing": "https://images.unsplash.com/photo-1460925895917-afdab827c52f?auto=format&fit=crop&w=900&q=80",
        "Business": "https://images.unsplash.com/photo-1521737604893-d14cc237f11d?auto=format&fit=crop&w=900&q=80"
    };

    return fallbackByCategory[course.category] || "https://images.unsplash.com/photo-1504384308090-c894fdcc538d?auto=format&fit=crop&w=900&q=80";
}

// ================================
// Check User Status
// ================================
function checkUserStatus() {
    const user = localStorage.getItem('user');
    if (user) {
        currentUser = JSON.parse(user);
    }
}

// ================================
// Enroll in Course
// ================================
async function enrollNow() {
    if (!currentUser) {
        showAlert('Please login to enroll in this course', 'info');
        openModal('loginModal');
        return;
    }

    if (courseData && courseData.is_enrolled) {
        showAlert('You are already enrolled in this course', 'info');
        updateEnrollButtons(true);
        return;
    }

    try {
        const response = await fetch('/api/enroll-course', {
            method: 'POST',
            credentials: 'same-origin',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                course_id: parseInt(courseId)
            })
        });

        const data = await response.json();

        if (data.status === 'success') {
            showAlert('Successfully enrolled! Reloading course content...', 'success');
            if (courseData) courseData.is_enrolled = true;
            updateEnrollButtons(true);
            // Reload to show videos
            setTimeout(() => {
                loadCourseDetails();
            }, 1000);
        } else {
            showAlert(data.message || 'Enrollment failed. Please try again.', 'error');
        }
    } catch (error) {
        showAlert('Connection error. Please check your internet connection.', 'error');
        console.error('Enrollment error:', error);
    }
}

// ================================
// Utility Functions
// ================================
function openModal(modalId) {
    const modal = document.getElementById(modalId);
    if (modal) {
        modal.classList.add('active');
    }
}

function closeModal(modalId) {
    const modal = document.getElementById(modalId);
    if (modal) {
        modal.classList.remove('active');
    }
}

function showAlert(message, type = 'info') {
    const alertContainer = document.getElementById('alertContainer');
    const alertId = 'alert-' + Date.now();

    const alertHTML = `
        <div id="${alertId}" class="alert alert-${type}" style="animation: slideIn 0.3s ease;">
            <strong>${type.charAt(0).toUpperCase() + type.slice(1)}!</strong> ${message}
        </div>
    `;

    alertContainer.insertAdjacentHTML('beforeend', alertHTML);

    setTimeout(() => {
        const alert = document.getElementById(alertId);
        if (alert) {
            alert.style.animation = 'slideOut 0.3s ease';
            setTimeout(() => alert.remove(), 300);
        }
    }, 4000);
}

function logout() {
    fetch('/api/logout', { method: 'POST', credentials: 'same-origin' }).catch(() => {});
    localStorage.removeItem('session_id');
    localStorage.removeItem('user');
    window.location.href = '/';
}